execute as @e[tag=corrupted] at @s run setblock ~ ~-1 ~ minecraft:sculk
execute as @e[tag=corrupted] at @s run setblock ~ ~-1 ~ minecraft:sculk_vein