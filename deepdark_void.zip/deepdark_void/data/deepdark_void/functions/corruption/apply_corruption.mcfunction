execute as @e[in=deepdark_void:void_dimension] run tag @s add corrupted
execute as @e[tag=corrupted] run effect give @s glowing 5 0 true
execute as @e[tag=corrupted] run effect give @s strength 6 0 true
execute as @e[tag=corrupted] run effect give @s resistance 6 0 true
execute as @e[tag=corrupted] run particle minecraft:sculk_soul ~ ~1 ~ 0.2 0.3 0.2 0.01 3 force
execute as @e[tag=corrupted] run playsound minecraft:block.sculk_sensor.clicking hostile @a ~ ~ ~ 0.3 0.7