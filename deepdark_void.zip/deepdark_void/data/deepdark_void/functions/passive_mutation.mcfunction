execute as @e[type=minecraft:cow,nbt={Age:-24000}] run tag @s add mutant
execute as @e[type=minecraft:pig,nbt={Age:-24000}] run tag @s add mutant
execute as @e[type=minecraft:sheep,nbt={Age:-24000}] run tag @s add mutant
execute as @e[type=minecraft:chicken,nbt={Age:-24000}] run tag @s add mutant
execute as @e[tag=mutant] run attribute @s minecraft:generic.max_health base set 40
execute as @e[tag=mutant] run attribute @s minecraft:generic.attack_damage base set 6
execute as @e[tag=mutant] run attribute @s minecraft:generic.movement_speed base set 0.35
execute as @e[tag=mutant] run data merge entity @s {CustomName:'{"text":"Mutated Beast","color":"dark_aqua"}'}
execute as @e[tag=mutant] at @s run particle minecraft:sculk_soul ~ ~1 ~ 0.3 0.5 0.3 0.01 6 force