# Rayon base selon bloc sous la balise
scoreboard players set @s beacon_base_radius 0
execute if block ~ ~-1 ~ minecraft:iron_block run scoreboard players set @s beacon_base_radius 20
execute if block ~ ~-1 ~ minecraft:gold_block run scoreboard players set @s beacon_base_radius 30
execute if block ~ ~-1 ~ minecraft:diamond_block run scoreboard players set @s beacon_base_radius 40
execute if block ~ ~-1 ~ minecraft:emerald_block run scoreboard players set @s beacon_base_radius 50
execute if block ~ ~-1 ~ minecraft:netherite_block run scoreboard players set @s beacon_base_radius 60
execute if block ~ ~-1 ~ enderite:enderite_block run scoreboard players set @s beacon_base_radius 80
execute if block ~ ~-1 ~ deepdark_void:vide_block run scoreboard players set @s beacon_base_radius 100

# Bonus niveaux (2 à 6) : +20 par couche
scoreboard players set @s beacon_bonus 0
execute if block ~ ~-2 ~ #minecraft:beacon_base_blocks run scoreboard players add @s beacon_bonus 20
execute if block ~ ~-3 ~ #minecraft:beacon_base_blocks run scoreboard players add @s beacon_bonus 20
execute if block ~ ~-4 ~ #minecraft:beacon_base_blocks run scoreboard players add @s beacon_bonus 20
execute if block ~ ~-5 ~ #minecraft:beacon_base_blocks run scoreboard players add @s beacon_bonus 20
execute if block ~ ~-6 ~ #minecraft:beacon_base_blocks run scoreboard players add @s beacon_bonus 20

# Rayon total = base + bonus
scoreboard players operation @s ddv.radius = @s beacon_base_radius
scoreboard players operation @s ddv.radius += @s beacon_bonus

# Purification basique (plantes/eau) autour de la balise
execute positioned ~ ~ ~ run fill ~-5 ~-5 ~-5 ~5 ~5 ~5 air replace minecraft:sculk
execute positioned ~ ~ ~ run fill ~-3 ~ ~-3 ~3 ~2 ~3 water replace minecraft:sculk

# Buffs niv 5 (Enderite) : rayon ~140
execute if score @s ddv.radius matches 140..159 as @a[distance=..160] run effect give @s haste 40 2 true
execute if score @s ddv.radius matches 140..159 as @a[distance=..160] run effect give @s speed 40 1 true

# Buffs niv 6 (Vide) : rayon >=180
execute if score @s ddv.radius matches 180.. as @a[distance=..200] run effect give @s haste 60 3 true
execute if score @s ddv.radius matches 180.. as @a[distance=..200] run effect give @s speed 60 2 true
execute if score @s ddv.radius matches 180.. as @a[distance=..200] run effect give @s strength 60 1 true

# Effets mobs
execute as @e[type=#minecraft:hostiles,distance=..200] run effect give @s weakness 30 1 true
execute if score @s ddv.radius matches 180.. run kill @e[type=#minecraft:hostiles,distance=..50]

# Particules de purification
particle minecraft:portal ~ ~10 ~ 3 25 3 0.1 150 force
