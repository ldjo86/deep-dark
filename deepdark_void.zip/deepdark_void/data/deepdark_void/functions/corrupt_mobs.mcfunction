execute as @e[type=minecraft:blaze] in deepdark_void:void_dimension run tag @s add corrupted
execute as @e[type=minecraft:bogged] in deepdark_void:void_dimension run tag @s add corrupted
execute as @e[type=minecraft:breeze] in deepdark_void:void_dimension run tag @s add corrupted
...
execute as @e[type=minecraft:wolf] in deepdark_void:void_dimension run tag @s add corrupted