scoreboard players set @s ddv.level 0

execute if block ~ ~-1 ~ minecraft:iron_block run scoreboard players set @s ddv.level 1
execute if block ~ ~-1 ~ minecraft:gold_block run scoreboard players set @s ddv.level 2
execute if block ~ ~-1 ~ minecraft:diamond_block run scoreboard players set @s ddv.level 3
execute if block ~ ~-1 ~ minecraft:emerald_block run scoreboard players set @s ddv.level 4
execute if block ~ ~-1 ~ minecraft:netherite_block run scoreboard players set @s ddv.level 5
execute if block ~ ~-1 ~ enderite:enderite_block run scoreboard players set @s ddv.level 6
execute if block ~ ~-1 ~ deepdark_void:vide_block run scoreboard players set @s ddv.level 7


scoreboard players set @s ddv.radius 40

execute if block ~ ~-2 ~ #minecraft:beacon_base_blocks run scoreboard players add @s ddv.radius 20
execute if block ~ ~-3 ~ #minecraft:beacon_base_blocks run scoreboard players add @s ddv.radius 20
execute if block ~ ~-4 ~ #minecraft:beacon_base_blocks run scoreboard players add @s ddv.radius 20
execute if block ~ ~-5 ~ #minecraft:beacon_base_blocks run scoreboard players add @s ddv.radius 20
execute if block ~ ~-6 ~ #minecraft:beacon_base_blocks run scoreboard players add @s ddv.radius 20


execute as @a[distance=..120] run effect clear @s minecraft:darkness
execute as @a[distance=..120] run effect give @s night_vision 3 0 true


execute positioned ~ ~ ~ run fill ~-8 ~-6 ~-8 ~8 ~6 ~8 air replace minecraft:sculk
execute positioned ~ ~ ~ run fill ~-8 ~-6 ~-8 ~8 ~6 ~8 air replace minecraft:sculk_catalyst
execute positioned ~ ~ ~ run fill ~-8 ~-6 ~-8 ~8 ~6 ~8 air replace minecraft:sculk_sensor
execute positioned ~ ~ ~ run fill ~-8 ~-6 ~-8 ~8 ~6 ~8 air replace minecraft:sculk_shrieker
execute positioned ~ ~ ~ run fill ~-8 ~-6 ~-8 ~8 ~6 ~8 air replace minecraft:sculk_vein


execute if score @s ddv.level matches 6 as @a[distance=..120] run effect give @s haste 60 3 true
execute if score @s ddv.level matches 6 as @a[distance=..120] run effect give @s speed 60 2 true


execute if score @s ddv.level matches 7 as @a[distance=..140] run effect give @s haste 60 4 true
execute if score @s ddv.level matches 7 as @a[distance=..140] run effect give @s speed 60 3 true
execute if score @s ddv.level matches 7 as @a[distance=..140] run effect give @s strength 60 2 true


particle minecraft:end_rod ~ ~20 ~ 4 20 4 0 30 force
particle minecraft:glow ~ ~15 ~ 2 10 2 0.01 40 force
particle minecraft:portal ~ ~30 ~ 6 1 6 0.05 80 force
particle minecraft:reverse_portal ~ ~30 ~ 6 1 6 0.05 80 force