
execute as @e[tag=corrupted] run effect give @s minecraft:strength 10 1 true
execute as @e[tag=corrupted] run effect give @s minecraft:speed 10 0 true
execute as @e[tag=corrupted] run effect give @s minecraft:resistance 10 0 true

execute as @e[tag=corrupted] at @s run particle minecraft:sculk_soul ~ ~1 ~ 0.4 0.6 0.4 0.01 4 force
