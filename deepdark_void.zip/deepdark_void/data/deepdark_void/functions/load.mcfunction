scoreboard objectives add ddv.radius dummy
scoreboard objectives add beacon_base_radius dummy
scoreboard objectives add beacon_bonus dummy

tellraw @a [{"text":"[DeepDark Void] ","color":"dark_purple"},{"text":"Datapack chargé","color":"gray"}]
