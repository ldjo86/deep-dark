execute as @e[type=minecraft:cow] at @s if block ~ ~-1 ~ minecraft:sculk run data merge entity @s {InLove:600}
execute as @e[type=minecraft:pig] at @s if block ~ ~-1 ~ minecraft:sculk run data merge entity @s {InLove:600}
execute as @e[type=minecraft:sheep] at @s if block ~ ~-1 ~ minecraft:sculk run data merge entity @s {InLove:600}
execute as @e[type=minecraft:chicken] at @s if block ~ ~-1 ~ minecraft:sculk run data merge entity @s {InLove:600}