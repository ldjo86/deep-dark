# obscurité dans l'overworld corrompu
execute as @a[in=deepdark_void:void_dimension] run effect give @s darkness 6 0 true

# particules sculk dans l'air
execute as @a[in=deepdark_void:void_dimension] at @s run particle minecraft:sculk_soul ~ ~4 ~ 0.5 2 0.5 0.01 2 force
execute as @a[in=deepdark_void:void_dimension] at @s run particle minecraft:ash ~ ~5 ~ 1 2 1 0.01 3 force