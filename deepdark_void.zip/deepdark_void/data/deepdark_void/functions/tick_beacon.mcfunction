execute in deepdark_void:void_dimension as @e[type=minecraft:beacon,nbt={Primary:1b}] at @s run function deepdark_void:beacon_effect
